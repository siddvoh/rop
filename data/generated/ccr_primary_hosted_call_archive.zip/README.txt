Returned-Object Profile hosted-call records

CALLS.jsonl contains the 10,192 issued bridge, rewrite, and paper-scoped
answer tasks. Each row retains the exact terminal model-visible request, the
response text consumed by the strict parser, sanitized token usage, source
hashes, parser output, and a binding to the released scientific result row.

UNISSUED_ANSWER_CELLS.jsonl contains the eight predicted-fact or rewrite
answer cells suppressed by invalid upstream outputs. The planned answer
population is therefore 6,600 cells with 6,592 issued calls.

Provider response IDs, timestamps, prices, headers, signatures, credentials,
and machine-local paths are absent. The included verifier checks every record
offline.
