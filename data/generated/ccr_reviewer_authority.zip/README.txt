Qwen and broad-development retrieval evidence

qwen/records.jsonl contains the 335-row open-weight selection scope, final hybrid rankings, exact decoded-ID BM25 reuse, and resolver status.
broad_development/records.jsonl contains the 1,397-item two-query by five-retriever grid reported in the paper.
PROTOCOL.json records the executed model, retrieval identities, and source hashes.
